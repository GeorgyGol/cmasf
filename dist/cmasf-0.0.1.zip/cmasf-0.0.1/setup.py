from distutils.core import setup

setup(
    name='cmasf',
    version='0.0.1',
    packages=['cmasf'],
    url='',
    license='',
    author='G. Golyshev',
    install_requires=['pandas', 'sqlalchemy', 'numpy', 'scipy'],
    author_email='g.golyshev@forecast.ru',
    description='CMASF functions and classes'
)
